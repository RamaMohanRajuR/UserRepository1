package com.practice.user.demo.user3;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;

import com.sun.istack.NotNull;

@Entity
@Table(name = "tbl_emp")
public class UserEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "first_name")
	@NotEmpty(message="Please enter the firstName")
	private String firstName;

	@Column(name = "last_name")
	@NotEmpty(message="Please enter the lastName")
	private String lastName;

	@Column(name = "email")
	@Email(message="Please enter the email with right format")
	private String email;

	public Long getId() {
		return id;
	}

	public void setId(Long pId) {
		id = pId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String pFirstName) {
		firstName = pFirstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String pLastName) {
		lastName = pLastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String pEmail) {
		email = pEmail;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Id = " + id + " firstName = " + firstName + " lastName = " + lastName + " email = " + email;
	}
}
