package com.practice.user.demo.user3;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@SuppressWarnings({ "unchecked", "rawtypes" })
@ControllerAdvice
public class CustomExceptionHandler extends ResponseEntityExceptionHandler {

	@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException pEx,
			HttpHeaders pHeaders, HttpStatus pStatus, WebRequest pRequest) {

		 List<String> details = new ArrayList<>();
	        for(ObjectError error : pEx.getBindingResult().getAllErrors()) {
	            details.add(error.getDefaultMessage());
	        }

		return new ResponseEntity(new ErrorResponse("Validation Failed",details), HttpStatus.BAD_REQUEST);
	}

}
