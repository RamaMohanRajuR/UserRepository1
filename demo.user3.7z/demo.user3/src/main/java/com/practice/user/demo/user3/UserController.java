package com.practice.user.demo.user3;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/users")
public class UserController {

	@Autowired
	private UserService service;

	@PostMapping(path = "/", consumes = "application/json", produces = "application/json")
	public ResponseEntity<Object> addUser(@Valid @RequestBody UserEntity userEntity) {
		UserEntity user = service.createOrUpdateUser(userEntity);
		return new ResponseEntity<>(user, HttpStatus.CREATED);
	}

	@GetMapping(path = "/")
	public ResponseEntity<List<UserEntity>> getAllUsers() {
		List<UserEntity> listOfUserEntity = service.getAllUsers();
		return new ResponseEntity(listOfUserEntity, new HttpHeaders(), HttpStatus.OK);
	}

	@GetMapping(path = "/{id}")
	public ResponseEntity<List<UserEntity>> findUserById(@PathVariable("id") Long id) throws RecordNotFoundException {
		UserEntity userEntity = service.findUserById(id);
		return new ResponseEntity(userEntity, new HttpHeaders(), HttpStatus.OK);
	}

	@DeleteMapping
	public ResponseEntity<Object> deleteUser(@RequestParam String email) {

		boolean isDeleted = service.deleteUserByEmail(email);

		if(isDeleted){
			return  new ResponseEntity(HttpStatus.OK);
		}else{
			return new ResponseEntity(HttpStatus.NOT_FOUND);
		}
		
	}
	
	
	
	

}
