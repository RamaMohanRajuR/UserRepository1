package com.practice.user.demo.user3;

import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.ParameterExpression;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;

@Service
@Transactional
public class UserService {

	@Autowired
	private ApplicationEventPublisher applicationEventPublisher;

	@Autowired
	private UserRepository repository;

	@Autowired
	private EntityManager entityManager;

	public UserEntity createOrUpdateUser(UserEntity userEntity) {

		Optional<UserEntity> optionalUserEntity = null;
		
		CustomSpringEvent customSpringEvent = new CustomSpringEvent(this, "User "+ userEntity+" Added");
		
        applicationEventPublisher.publishEvent(customSpringEvent);

		if (userEntity.getId() != null) {
			optionalUserEntity = repository.findById(userEntity.getId());
		}
		if (optionalUserEntity != null && optionalUserEntity.isPresent()) {
			UserEntity oldEntity = optionalUserEntity.get();
			oldEntity.setFirstName(userEntity.getFirstName());
			oldEntity.setLastName(userEntity.getLastName());
			oldEntity.setEmail(userEntity.getEmail());
			return oldEntity;
		} else {
			return repository.save(userEntity);
		}
		
	
	}

	public UserEntity findUserById(Long id) throws RecordNotFoundException {

		Optional<UserEntity> optionalUserEntity = repository.findById(id);

		if (optionalUserEntity.isPresent()) {
			return optionalUserEntity.get();
		} else {
			throw new RecordNotFoundException("No user found with that id");
		}

	}

	public List<UserEntity> getAllUsers() {
		return repository.findAll();
	}

	public boolean deleteUserByEmail(String email) {
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();

		CriteriaQuery<UserEntity> q = cb.createQuery(UserEntity.class);
		Root<UserEntity> c = q.from(UserEntity.class);
		ParameterExpression<String> p = cb.parameter(String.class);
		q.select(c).where(cb.equal(c.get("email"), p));
		TypedQuery<UserEntity> query = entityManager.createQuery(q);
		query.setParameter(p, email);
		Optional<UserEntity> optionalUser = query.getResultList().stream().findAny();

		Optional<UserEntity> optionalUserEntity = null;
		
		CustomSpringEvent customSpringEvent = new CustomSpringEvent(this, "User "+optionalUser.get() +" deleted");
		
        applicationEventPublisher.publishEvent(customSpringEvent);
		
		if (optionalUser.isPresent()) {
			UserEntity userEntity = optionalUser.get();
			repository.delete(userEntity);
			return true;
		}
		return false;
	}

}
